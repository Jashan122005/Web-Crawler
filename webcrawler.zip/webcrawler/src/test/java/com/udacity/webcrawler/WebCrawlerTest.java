package com.udacity.webcrawler;

import com.google.inject.Guice;
import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.json.CrawlerConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import javax.inject.Inject;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static com.google.common.truth.Truth.assertThat;
import static com.google.common.truth.Truth.assertWithMessage;

/**
 * Full WebCrawler tests.
 */
public final class WebCrawlerTest {

    @Inject
    private WebCrawler crawler;

    private static final String DATA_DIR =
            System.getProperty("testDataDir");

    /*
     * PROVIDE IMPLEMENTATIONS
     */
    static Stream<Class<?>> provideTestParameters()
            throws Exception {

        String[] names =
                System.getProperty(
                                "crawlerImplementations")
                        .split("\\s+");

        List<Class<?>> classes =
                new ArrayList<>();

        for (String name : names) {

            classes.add(
                    Class.forName(
                            name.strip()));
        }

        return classes.stream();
    }

    /* ===================== OVERRIDE TESTS ===================== */

    @Test
    public void testOverrideToSequential() {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setImplementationOverride(
                                SequentialWebCrawler.class.getName())

                        .setParallelism(12)

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        assertThat(
                crawler.getClass())

                .isAssignableTo(
                        SequentialWebCrawler.class);
    }

    @Test
    public void testOverrideToParallel() {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setImplementationOverride(
                                ParallelWebCrawler.class.getName())

                        .setParallelism(12)

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        assertThat(
                crawler.getClass())

                .isAssignableTo(
                        ParallelWebCrawler.class);
    }

    /* ===================== PARALLELISM TESTS ===================== */

    @Test
    public void testSequentialParallelism() {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setParallelism(1)

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        assertThat(
                crawler.getClass())

                .isAssignableTo(
                        SequentialWebCrawler.class);
    }

    @Test
    public void testParallelParallelism() {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setParallelism(2)

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        assertThat(
                crawler.getClass())

                .isAssignableTo(
                        ParallelWebCrawler.class);
    }

    /* ===================== ZERO DEPTH ===================== */

    @ParameterizedTest
    @MethodSource("provideTestParameters")
    public void zeroMaxDepth(
            Class<?> crawlerClass) {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setImplementationOverride(
                                crawlerClass.getName())

                        .setMaxDepth(0)

                        .setPopularWordCount(3)

                        .addStartPages(

                                Paths.get(
                                                DATA_DIR,
                                                "test-page.html")
                                        .toUri()
                                        .toString())

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        CrawlResult result =
                crawler.crawl(
                        config.getStartPages());

        assertThat(
                result.getUrlsVisited())

                .isEqualTo(0);

        assertThat(
                result.getWordCounts())

                .isEmpty();
    }

    /* ===================== NO START PAGES ===================== */

    @ParameterizedTest
    @MethodSource("provideTestParameters")
    public void noStartPages(
            Class<?> crawlerClass) {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setImplementationOverride(
                                crawlerClass.getName())

                        .setMaxDepth(10)

                        .setPopularWordCount(3)

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        CrawlResult result =
                crawler.crawl(
                        config.getStartPages());

        assertThat(
                result.getUrlsVisited())

                .isEqualTo(0);

        assertThat(
                result.getWordCounts())

                .isEmpty();
    }

    /* ===================== BASIC CRAWL ===================== */

    @ParameterizedTest
    @MethodSource("provideTestParameters")
    public void testBasicCrawl(
            Class<?> crawlerClass) {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setImplementationOverride(
                                crawlerClass.getName())

                        .setMaxDepth(10)

                        .setPopularWordCount(3)

                        .addStartPages(

                                Paths.get(
                                                DATA_DIR,
                                                "test-page.html")
                                        .toUri()
                                        .toString())

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        CrawlResult result =
                crawler.crawl(
                        config.getStartPages());

        assertWithMessage(
                "Wrong visited URL count")

                .that(
                        result.getUrlsVisited())

                .isEqualTo(3);

        assertThat(
                result.getWordCounts())

                .containsEntry(
                        "the",
                        4);

        assertThat(
                result.getWordCounts())

                .containsEntry(
                        "jumped",
                        2);

        assertThat(
                result.getWordCounts())

                .containsEntry(
                        "brown",
                        2);

        assertThat(
                result.getWordCounts()
                        .entrySet())

                .containsExactly(

                        Map.entry("the", 4),

                        Map.entry("jumped", 2),

                        Map.entry("brown", 2))

                .inOrder();
    }

    /* ===================== IGNORED URLS ===================== */

    @ParameterizedTest
    @MethodSource("provideTestParameters")
    public void respectsIgnoredUrls(
            Class<?> crawlerClass) {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setImplementationOverride(
                                crawlerClass.getName())

                        .setMaxDepth(10)

                        .setPopularWordCount(3)

                        .addStartPages(
                                Paths.get(
                                                DATA_DIR,
                                                "test-page.html")
                                        .toUri()
                                        .toString())

                        .addStartPages(
                                Paths.get(
                                                DATA_DIR,
                                                "infinite-loop.html")
                                        .toUri()
                                        .toString())

                        .addIgnoredUrls(
                                ".*-loop\\.html$")

                        .addIgnoredUrls(
                                ".*dead-.*")

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        CrawlResult result =
                crawler.crawl(
                        config.getStartPages());

        assertThat(
                result.getUrlsVisited())

                .isEqualTo(2);

        assertThat(
                result.getWordCounts()
                        .entrySet())

                .containsExactly(

                        Map.entry("the", 4),

                        Map.entry("jumped", 2),

                        Map.entry("brown", 2))

                .inOrder();
    }

    /* ===================== IGNORED WORDS ===================== */

    @ParameterizedTest
    @MethodSource("provideTestParameters")
    public void respectsIgnoredWords(
            Class<?> crawlerClass) {

        CrawlerConfiguration config =

                new CrawlerConfiguration.Builder()

                        .setImplementationOverride(
                                crawlerClass.getName())

                        .setMaxDepth(10)

                        .setPopularWordCount(3)

                        .addStartPages(
                                Paths.get(
                                                DATA_DIR,
                                                "test-page.html")
                                        .toUri()
                                        .toString())

                        .addIgnoredWords(
                                "^...$")

                        .addIgnoredWords(
                                "^......$")

                        .build();

        Guice.createInjector(

                        new WebCrawlerModule(config),

                        new NoOpProfilerModule())

                .injectMembers(this);

        CrawlResult result =
                crawler.crawl(
                        config.getStartPages());

        assertThat(
                result.getUrlsVisited())

                .isEqualTo(3);

        assertThat(
                result.getWordCounts()
                        .entrySet())

                .containsExactly(

                        Map.entry("brown", 2),

                        Map.entry("quick", 2),

                        Map.entry("lazy", 2))

                .inOrder();
    }
}