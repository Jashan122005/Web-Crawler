package com.udacity.webcrawler;

import javax.inject.Qualifier;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Binding annotation for the maximum amount of time
 * the web crawler is allowed to execute.
 *
 * <p>The value associated with this annotation is a
 * {@link java.time.Duration} created from the
 * {@code "timeoutSeconds"} property in the crawler
 * configuration JSON.
 *
 * Example:
 *
 * <pre>
 * {
 *   "timeoutSeconds": 10
 * }
 * </pre>
 *
 * This means the crawler will stop processing once
 * the configured timeout duration has elapsed.
 */
@Qualifier
@Retention(RetentionPolicy.RUNTIME)
public @interface Timeout {
}