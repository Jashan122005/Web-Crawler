package com.udacity.webcrawler;

import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.profiler.Profiled;

import java.util.List;

/**
 * Main interface defining the API contract for all
 * web crawler implementations.
 *
 * <p>Implementations may perform crawling either
 * sequentially or in parallel.
 */
public interface WebCrawler {

    /**
     * Starts crawling from the provided list of URLs.
     *
     * <p>The crawler recursively visits pages,
     * extracts words and links, and returns
     * the final crawl statistics and word counts.
     *
     * @param startingUrls the initial URLs where crawling begins
     * @return the {@link CrawlResult} containing:
     *         <ul>
     *             <li>Most popular word counts</li>
     *             <li>Total number of visited URLs</li>
     *         </ul>
     */
    @Profiled
    CrawlResult crawl(List<String> startingUrls);

    /**
     * Returns the maximum level of parallelism
     * supported by this crawler implementation.
     *
     * <p>Sequential crawlers return {@code 1},
     * while parallel crawlers typically return
     * the number of available processor cores.
     *
     * @return maximum supported parallelism
     */
    default int getMaxParallelism() {
        return 1;
    }
}