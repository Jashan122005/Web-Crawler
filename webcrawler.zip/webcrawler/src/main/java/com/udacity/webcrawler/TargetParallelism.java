package com.udacity.webcrawler;

import javax.inject.Qualifier;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Binding annotation for the target level of parallelism
 * used by the parallel web crawler.
 *
 * <p>The value associated with this annotation represents
 * the number of CPU threads/cores the crawler should utilize
 * while processing pages concurrently.
 *
 * <p>This value is loaded from the crawler configuration JSON
 * using the key:
 *
 * <pre>
 * "targetParallelism"
 * </pre>
 *
 * Example:
 *
 * <pre>
 * {
 *   "targetParallelism": 8
 * }
 * </pre>
 */
@Qualifier
@Retention(RetentionPolicy.RUNTIME)
public @interface TargetParallelism {
}