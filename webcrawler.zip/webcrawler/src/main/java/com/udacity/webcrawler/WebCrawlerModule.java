package com.udacity.webcrawler;

import com.google.inject.AbstractModule;
import com.google.inject.Key;
import com.google.inject.Provides;
import com.google.inject.ProvisionException;
import com.google.inject.Singleton;
import com.google.inject.multibindings.Multibinder;
import com.udacity.webcrawler.json.CrawlerConfiguration;
import com.udacity.webcrawler.parser.ParserModule;
import com.udacity.webcrawler.profiler.Profiler;

import javax.inject.Qualifier;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.time.Clock;
import java.time.Duration;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Guice dependency injection module responsible for
 * configuring and providing all dependencies required
 * by the web crawler application.
 *
 * <p>Example usage:
 *
 * <pre>
 * CrawlerConfiguration config = ...;
 *
 * WebCrawler crawler =
 *     Guice.createInjector(new WebCrawlerModule(config))
 *          .getInstance(WebCrawler.class);
 * </pre>
 */
public final class WebCrawlerModule extends AbstractModule {

    private final CrawlerConfiguration config;

    /**
     * Creates a module using the provided crawler configuration.
     *
     * @param config crawler configuration loaded from JSON
     */
    public WebCrawlerModule(CrawlerConfiguration config) {
        this.config = Objects.requireNonNull(config);
    }

    @Override
    protected void configure() {

        /*
         * Multibinder allows multiple implementations
         * of WebCrawler to be registered and selected
         * dynamically at runtime.
         */
        Multibinder<WebCrawler> multibinder =
                Multibinder.newSetBinder(
                        binder(),
                        WebCrawler.class,
                        Internal.class);

        multibinder.addBinding().to(SequentialWebCrawler.class);
        multibinder.addBinding().to(ParallelWebCrawler.class);

        // Core dependencies
        bind(Clock.class).toInstance(Clock.systemUTC());

        // Configuration bindings
        bind(Key.get(Integer.class, MaxDepth.class))
                .toInstance(config.getMaxDepth());

        bind(Key.get(Integer.class, PopularWordCount.class))
                .toInstance(config.getPopularWordCount());

        bind(Key.get(Duration.class, Timeout.class))
                .toInstance(config.getTimeout());

        bind(new Key<List<Pattern>>(IgnoredUrls.class) {})
                .toInstance(config.getIgnoredUrls());

        /*
         * Install parser module with parser-specific
         * configuration values.
         */
        install(
                new ParserModule.Builder()
                        .setTimeout(config.getTimeout())
                        .setIgnoredWords(config.getIgnoredWords())
                        .build()
        );
    }

    /**
     * Provides the raw crawler implementation.
     *
     * <p>If an implementation override is configured,
     * that implementation is selected directly.
     *
     * <p>Otherwise, the first crawler capable of
     * supporting the requested parallelism is selected.
     */
    @Provides
    @Singleton
    @Internal
    WebCrawler provideRawWebCrawler(
            @Internal Set<WebCrawler> implementations,
            @TargetParallelism int targetParallelism) {

        String override = config.getImplementationOverride();

        // Use explicitly requested implementation
        if (!override.isEmpty()) {
            return implementations.stream()
                    .filter(impl ->
                            impl.getClass().getName().equals(override))
                    .findFirst()
                    .orElseThrow(() ->
                            new ProvisionException(
                                    "Implementation not found: " + override));
        }

        // Select implementation based on supported parallelism
        return implementations.stream()
                .filter(impl ->
                        targetParallelism <= impl.getMaxParallelism())
                .findFirst()
                .orElseThrow(() ->
                        new ProvisionException(
                                "No implementation able to handle parallelism = \""
                                        + config.getParallelism()
                                        + "\"."));
    }

    /**
     * Provides the target parallelism value.
     *
     * <p>If the configuration specifies a valid value,
     * it is used directly. Otherwise, the number of
     * available processor cores is used.
     */
    @Provides
    @Singleton
    @TargetParallelism
    int provideTargetParallelism() {

        if (config.getParallelism() >= 0) {
            return config.getParallelism();
        }

        return Runtime.getRuntime().availableProcessors();
    }

    /**
     * Wraps the selected crawler with a profiling proxy.
     */
    @Provides
    @Singleton
    WebCrawler provideWebCrawlerProxy(
            Profiler profiler,
            @Internal WebCrawler delegate) {

        return profiler.wrap(WebCrawler.class, delegate);
    }

    /**
     * Internal binding annotation used to distinguish
     * raw crawler implementations from the profiled proxy.
     */
    @Qualifier
    @Retention(RetentionPolicy.RUNTIME)
    private @interface Internal {
    }
}