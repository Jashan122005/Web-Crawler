package com.udacity.webcrawler;

import com.udacity.webcrawler.json.CrawlResult;
import com.udacity.webcrawler.parser.PageParser;
import com.udacity.webcrawler.parser.PageParserFactory;

import javax.inject.Inject;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * A {@link WebCrawler} implementation that crawls web pages sequentially,
 * processing one page at a time.
 */
final class SequentialWebCrawler implements WebCrawler {

    private final Clock clock;
    private final PageParserFactory parserFactory;
    private final Duration timeout;
    private final int popularWordCount;
    private final int maxDepth;
    private final List<Pattern> ignoredUrls;

    @Inject
    SequentialWebCrawler(
            Clock clock,
            PageParserFactory parserFactory,
            @Timeout Duration timeout,
            @PopularWordCount int popularWordCount,
            @MaxDepth int maxDepth,
            @IgnoredUrls List<Pattern> ignoredUrls) {

        this.clock = clock;
        this.parserFactory = parserFactory;
        this.timeout = timeout;
        this.popularWordCount = popularWordCount;
        this.maxDepth = maxDepth;
        this.ignoredUrls = ignoredUrls;
    }

    @Override
    public CrawlResult crawl(List<String> startingUrls) {

        Instant deadline = clock.instant().plus(timeout);

        Map<String, Integer> wordCounts = new HashMap<>();
        Set<String> visitedUrls = new HashSet<>();

        for (String url : startingUrls) {
            crawlInternal(
                    url,
                    deadline,
                    maxDepth,
                    wordCounts,
                    visitedUrls);
        }

        Map<String, Integer> sortedCounts =
                WordCounts.sort(wordCounts, popularWordCount);

        return new CrawlResult.Builder()
                .setWordCounts(sortedCounts)
                .setUrlsVisited(visitedUrls.size())
                .build();
    }

    /**
     * Recursively crawls pages starting from the given URL.
     */
    private void crawlInternal(
            String url,
            Instant deadline,
            int depth,
            Map<String, Integer> wordCounts,
            Set<String> visitedUrls) {

        // Stop if max depth reached
        if (depth == 0) {
            return;
        }

        // Stop if timeout exceeded
        if (clock.instant().isAfter(deadline)) {
            return;
        }

        // Ignore matching URLs
        for (Pattern pattern : ignoredUrls) {
            if (pattern.matcher(url).matches()) {
                return;
            }
        }

        // Skip already visited URLs
        if (!visitedUrls.add(url)) {
            return;
        }

        // Parse current page
        PageParser.Result result =
                parserFactory.get(url).parse();

        // Merge word counts
        result.getWordCounts().forEach(
                (word, count) ->
                        wordCounts.merge(word, count, Integer::sum)
        );

        // Recursively crawl discovered links
        for (String link : result.getLinks()) {
            crawlInternal(
                    link,
                    deadline,
                    depth - 1,
                    wordCounts,
                    visitedUrls);
        }
    }
}