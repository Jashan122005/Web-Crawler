import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.UncheckedIOException;

import java.nio.file.Files;
import java.nio.file.StandardOpenOption;

class CrawlResult {

    private final Map<String, Integer> wordCounts;

    private final int urlsVisited;

    public CrawlResult(
            Map<String, Integer> wordCounts,
            int urlsVisited) {

        this.wordCounts = wordCounts;

        this.urlsVisited = urlsVisited;
    }

    public Map<String, Integer> getWordCounts() {

        return wordCounts;
    }

    public int getUrlsVisited() {

        return urlsVisited;
    }
}

/* ===================== CRAWL RESULT WRITER ===================== */

class CrawlResultWriter {

    private final CrawlResult result;

    public CrawlResultWriter(
            CrawlResult result) {

        this.result =
                Objects.requireNonNull(result);
    }

    /*
     * WRITE JSON TO FILE
     */
    public void write(Path path) {

        Objects.requireNonNull(path);

        try (BufferedWriter writer =

                     Files.newBufferedWriter(

                             path,

                             StandardOpenOption.CREATE,

                             StandardOpenOption.TRUNCATE_EXISTING)) {

            write(writer);

        } catch (IOException e) {

            throw new UncheckedIOException(e);
        }
    }

    /*
     * WRITE JSON TO WRITER
     */
    public void write(Writer writer) {

        Objects.requireNonNull(writer);

        try {

            StringBuilder json =
                    new StringBuilder();

            json.append("{\n");

            json.append("  \"wordCounts\": {\n");

            int size =
                    result.getWordCounts().size();

            int count = 0;

            for (Map.Entry<String, Integer> entry
                    : result.getWordCounts().entrySet()) {

                json.append("    \"")
                        .append(entry.getKey())
                        .append("\": ")
                        .append(entry.getValue());

                count++;

                if (count < size) {
                    json.append(",");
                }

                json.append("\n");
            }

            json.append("  },\n");

            json.append("  \"urlsVisited\": ")
                    .append(result.getUrlsVisited())
                    .append("\n");

            json.append("}\n");

            writer.write(json.toString());

            writer.flush();

        } catch (IOException e) {

            e.printStackTrace();
        }
    }
}

/* ===================== MAIN ===================== */

public class Main {

    public static void main(String[] args) {

        Map<String, Integer> counts =
                new HashMap<>();

        counts.put("java", 10);

        counts.put("crawler", 5);

        CrawlResult result =
                new CrawlResult(counts, 15);

        CrawlResultWriter writer =
                new CrawlResultWriter(result);

        /*
         * WRITE TO CONSOLE
         */
        StringWriter stringWriter =
                new StringWriter();

        writer.write(stringWriter);

        System.out.println(
                stringWriter.toString());

        /*
         * WRITE TO FILE
         */
        Path path =
                Paths.get("result.json");

        writer.write(path);

        System.out.println(
                "JSON written to result.json");
    }
}